<?php

namespace Maatwebsite\Excel\Concerns;

interface WithTitle
{
    /**
     * @return string
     */
    public function title(): string;
}
